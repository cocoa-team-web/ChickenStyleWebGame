import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';
import { MobileJoystick } from './mobileJoystick.js';

const game = document.querySelector('#game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 250, 900);

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 1200);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
game.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 2.2));
const sun = new THREE.DirectionalLight(0xffffff, 3.0);
sun.position.set(120, 180, 80);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -300;
sun.shadow.camera.right = 300;
sun.shadow.camera.top = 300;
sun.shadow.camera.bottom = -300;
scene.add(sun);

// Гигантская плоскость вместо карты.
const plane = new THREE.Mesh(
  new THREE.PlaneGeometry(1000, 1000),
  new THREE.MeshStandardMaterial({ color: 0x777b80, roughness: 0.95 })
);
plane.rotation.x = -Math.PI / 2;
plane.receiveShadow = true;
scene.add(plane);

// Сетка помогает видеть масштаб плоскости.
const grid = new THREE.GridHelper(1000, 100, 0x55585c, 0x686b70);
grid.position.y = 0.01;
scene.add(grid);

// Куб вместо модели игрока.
const player = new THREE.Mesh(
  new THREE.BoxGeometry(2, 2, 2),
  new THREE.MeshStandardMaterial({ color: 0xe8e8e8, roughness: 0.7 })
);
player.position.set(0, 1, 0);
player.castShadow = true;
scene.add(player);

const state = {
  keys: new Set(),
  joystickX: 0,
  joystickY: 0,
  velocityY: 0,
  grounded: true,
  cameraMode: 'third',
  yaw: 0,
  pitch: -0.15,
  cameraTouchId: null,
  lastTouchX: 0,
  lastTouchY: 0
};

const speed = 9;
const gravity = 26;
const jumpSpeed = 10;

function setCameraMode(mode) {
  state.cameraMode = mode;
  document.querySelector('#cameraButton').textContent = mode === 'third' ? '3 лицо' : '1 лицо';
}

function jump() {
  if (!state.grounded) return;
  state.velocityY = jumpSpeed;
  state.grounded = false;
}

function getMoveInput() {
  let x = state.joystickX;
  let z = state.joystickY;

  if (state.keys.has('KeyA')) x -= 1;
  if (state.keys.has('KeyD')) x += 1;
  if (state.keys.has('KeyW')) z -= 1;
  if (state.keys.has('KeyS')) z += 1;

  const length = Math.hypot(x, z);
  if (length > 1) {
    x /= length;
    z /= length;
  }
  return { x, z };
}

function updatePlayer(dt) {
  const input = getMoveInput();
  const sin = Math.sin(state.yaw);
  const cos = Math.cos(state.yaw);

  // Движение относительно направления камеры.
  const worldX = input.x * cos - input.z * sin;
  const worldZ = input.x * sin + input.z * cos;

  player.position.x += worldX * speed * dt;
  player.position.z += worldZ * speed * dt;

  state.velocityY -= gravity * dt;
  player.position.y += state.velocityY * dt;

  if (player.position.y <= 1) {
    player.position.y = 1;
    state.velocityY = 0;
    state.grounded = true;
  }

  // Куб поворачивается в сторону движения.
  if (Math.hypot(worldX, worldZ) > 0.01) {
    player.rotation.y = Math.atan2(worldX, worldZ);
  }
}

function updateCamera() {
  const target = player.position.clone();

  if (state.cameraMode === 'first') {
    camera.position.set(target.x, target.y + 0.65, target.z);
    camera.rotation.order = 'YXZ';
    camera.rotation.y = state.yaw;
    camera.rotation.x = state.pitch;
    return;
  }

  const distance = 8;
  const height = 4.2;
  const horizontal = new THREE.Vector3(
    Math.sin(state.yaw) * distance,
    height,
    Math.cos(state.yaw) * distance
  );

  camera.position.copy(target).add(horizontal);
  camera.lookAt(target.x, target.y + 0.7, target.z);
}

new MobileJoystick(document.querySelector('#joystick'), (x, y) => {
  state.joystickX = x;
  state.joystickY = y;
});

document.querySelector('#jumpButton').addEventListener('pointerdown', (event) => {
  event.preventDefault();
  jump();
});

document.querySelector('#cameraButton').addEventListener('click', () => {
  setCameraMode(state.cameraMode === 'third' ? 'first' : 'third');
});

window.addEventListener('keydown', (event) => {
  state.keys.add(event.code);
  if (event.code === 'Space') {
    event.preventDefault();
    jump();
  }
  if (event.code === 'Digit1') setCameraMode('first');
  if (event.code === 'Digit3') setCameraMode('third');
});

window.addEventListener('keyup', (event) => state.keys.delete(event.code));

// Поворот камеры мышью/свайпом справа от джойстика.
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (event.pointerType === 'mouse' && event.button !== 0) return;
  if (event.clientX < innerWidth * 0.42) return;
  state.cameraTouchId = event.pointerId;
  state.lastTouchX = event.clientX;
  state.lastTouchY = event.clientY;
  renderer.domElement.setPointerCapture?.(event.pointerId);
});

renderer.domElement.addEventListener('pointermove', (event) => {
  if (event.pointerId !== state.cameraTouchId) return;
  const dx = event.clientX - state.lastTouchX;
  const dy = event.clientY - state.lastTouchY;
  state.lastTouchX = event.clientX;
  state.lastTouchY = event.clientY;
  state.yaw -= dx * 0.006;
  state.pitch = THREE.MathUtils.clamp(state.pitch - dy * 0.004, -1.1, 0.8);
});

renderer.domElement.addEventListener('pointerup', (event) => {
  if (event.pointerId === state.cameraTouchId) state.cameraTouchId = null;
});

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

const clock = new THREE.Clock();
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  updatePlayer(dt);
  updateCamera();
  renderer.render(scene, camera);
}

setCameraMode('third');
animate();
