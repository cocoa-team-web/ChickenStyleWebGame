export class MobileJoystick {
  constructor(element, onMove) {
    this.element = element;
    this.onMove = onMove;
    this.active = false;
    this.pointerId = null;
    this.knob = document.createElement('div');
    this.knob.className = 'joystick-knob';
    this.element.appendChild(this.knob);

    this.element.addEventListener('pointerdown', (event) => this.start(event));
    window.addEventListener('pointermove', (event) => this.move(event));
    window.addEventListener('pointerup', (event) => this.end(event));
    window.addEventListener('pointercancel', (event) => this.end(event));
  }

  start(event) {
    if (this.active) return;
    this.active = true;
    this.pointerId = event.pointerId;
    this.element.setPointerCapture?.(event.pointerId);
    this.update(event.clientX, event.clientY);
    event.preventDefault();
  }

  move(event) {
    if (!this.active || event.pointerId !== this.pointerId) return;
    this.update(event.clientX, event.clientY);
    event.preventDefault();
  }

  update(clientX, clientY) {
    const rect = this.element.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const radius = Math.max(1, rect.width / 2 - 10);

    let dx = clientX - cx;
    let dy = clientY - cy;
    const length = Math.hypot(dx, dy);

    if (length > radius) {
      dx = (dx / length) * radius;
      dy = (dy / length) * radius;
    }

    this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    this.onMove(dx / radius, dy / radius);
  }

  end(event) {
    if (!this.active || event.pointerId !== this.pointerId) return;
    this.active = false;
    this.pointerId = null;
    this.knob.style.transform = 'translate(0, 0)';
    this.onMove(0, 0);
  }
}
